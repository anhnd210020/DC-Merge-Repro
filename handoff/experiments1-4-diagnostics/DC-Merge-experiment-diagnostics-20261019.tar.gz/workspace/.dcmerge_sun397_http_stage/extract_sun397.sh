#!/usr/bin/env bash
set -uo pipefail
archive=/workspace/.dcmerge_sun397_http_stage/sun397.tar
log=/srv/dcmerge/results/sun397-extract.log
printf '[%s] Starting extraction from verified staged archive.\n' "$(date -u '+%F %T UTC')" >> "$log"
if tar -xf "$archive" -C /workspace/datasets8 >> "$log" 2>&1; then
  printf '[%s] EXTRACT_OK\n' "$(date -u '+%F %T UTC')" >> "$log"
else
  rc=$?
  printf '[%s] EXTRACT_FAILED exit=%s\n' "$(date -u '+%F %T UTC')" "$rc" >> "$log"
  exit "$rc"
fi
