#!/usr/bin/env bash
set -euo pipefail

RESULTS=/srv/dcmerge/results
SETUP_LOG=/var/log/onstart.log
REPO=/workspace/ducanh/DC-Merge
EXP2="$RESULTS/experiment2"
OUT="$RESULTS/experiment3"
mkdir -p "$RESULTS"

printf '[%s] Waiting for DC-Merge assets and environment setup to finish.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
for attempt in $(seq 1 5760); do
  if grep -Fq 'SETUP COMPLETE' "$SETUP_LOG" 2>/dev/null; then
    break
  fi
  if ! pgrep -f '^bash /provisioning.sh$' >/dev/null 2>&1; then
    printf '[%s] Setup exited before completion; see %s.\n' "$(date -u '+%F %T UTC')" "$SETUP_LOG" | tee -a "$RESULTS/experiment3-runner.log"
    exit 2
  fi
  sleep 30
done
if ! grep -Fq 'SETUP COMPLETE' "$SETUP_LOG" 2>/dev/null; then
  printf '[%s] Timed out waiting for setup.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
  exit 2
fi

source /workspace/dcmerge_env.sh
cd "$REPO"
mkdir -p "$EXP2" "$OUT"

printf '[%s] Setup complete; checking required assets.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
test -d "$DCMERGE_MODEL_DIR"
test -d "$DCMERGE_FT_DIR"
test -d "$DCMERGE_HEAD_DIR/ViT-B-32"
test -d "$DCMERGE_DATA_DIR"
for dataset in cars dtd eurosat gtsrb MNIST resisc45 sun397 svhn; do
  test -d "$DCMERGE_DATA_DIR/$dataset"
done
for task in stanford_cars dtd eurosat gtsrb mnist resisc45 sun397 svhn; do
  test -s "$DCMERGE_FT_DIR/$task/adapter_config.json"
  test -s "$DCMERGE_FT_DIR/$task/adapter_model.bin"
  test -s "$DCMERGE_HEAD_DIR/ViT-B-32/${task}_head.pt"
done
test -s "$DCMERGE_MODEL_DIR/config.json"

BASELINE_CONTEXTS=(
  dtd-eurosat-gtsrb-svhn
  eurosat-gtsrb-mnist-svhn
  eurosat-gtsrb-sun397-svhn
  stanford_cars-eurosat-gtsrb-mnist
  stanford_cars-eurosat-gtsrb-resisc45
  stanford_cars-eurosat-mnist-resisc45
  stanford_cars-eurosat-mnist-sun397
)
baseline_files_complete() {
  local context method
  for context in "${BASELINE_CONTEXTS[@]}"; do
    for method in dc_rank ct; do
      [[ -s "$EXP2/compare/${context}__${method}.json" ]] || return 1
    done
  done
}

if ! baseline_files_complete; then
  printf '[%s] Required Experiment 2 baselines are missing; refusing to recreate or start the oracle.\n' \
    "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
  exit 3
fi

"$DCMERGE_MICROMAMBA" run -n "$DCMERGE_ENV_NAME" python - "$EXP2/compare" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
contexts = (
    "dtd-eurosat-gtsrb-svhn",
    "eurosat-gtsrb-mnist-svhn",
    "eurosat-gtsrb-sun397-svhn",
    "stanford_cars-eurosat-gtsrb-mnist",
    "stanford_cars-eurosat-gtsrb-resisc45",
    "stanford_cars-eurosat-mnist-resisc45",
    "stanford_cars-eurosat-mnist-sun397",
)
errors = []
for context in contexts:
    for method in ("dc_rank", "ct"):
        path = root / f"{context}__{method}.json"
        try:
            row = json.loads(path.read_text())
            if row.get("context") != context or row.get("method") != method:
                raise ValueError("context or method mismatch")
            if not row.get("test_acc") or "test_mean_norm" not in row:
                raise ValueError("missing result fields")
        except Exception as exc:
            errors.append(f"{path.name}: {type(exc).__name__}")
if errors:
    raise SystemExit("BASELINE CHECK FAILED:\n" + "\n".join(errors))
print("BASELINE CHECK PASS: 7 contexts x dc_rank/ct")
PY

printf '[%s] Running all seven lane-based baseline reproduction checks before any search.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
"$DCMERGE_MICROMAMBA" run -n "$DCMERGE_ENV_NAME" python /workspace/dcmerge_oracle_baseline_gate.py \
  --repo "$REPO" --model "$DCMERGE_MODEL_DIR" --ft-dir "$DCMERGE_FT_DIR" \
  --heads "$DCMERGE_HEAD_DIR" --data "$DCMERGE_DATA_DIR" --exp2 "$EXP2" \
  --out "$OUT" --contexts four --device cuda 2>&1 | tee -a "$RESULTS/experiment3-baseline-gate.log"

printf '[%s] Running the three core contexts.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
"$DCMERGE_MICROMAMBA" run -n "$DCMERGE_ENV_NAME" python lane_harm/run_oracle.py run \
  --repo "$REPO" --model "$DCMERGE_MODEL_DIR" --ft-dir "$DCMERGE_FT_DIR" \
  --heads "$DCMERGE_HEAD_DIR" --data "$DCMERGE_DATA_DIR" --exp2 "$EXP2" \
  --out "$OUT" --device cuda --contexts core 2>&1 | tee "$RESULTS/experiment3-core.log"

printf '[%s] Running all seven contexts; completed core contexts are skipped.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
"$DCMERGE_MICROMAMBA" run -n "$DCMERGE_ENV_NAME" python lane_harm/run_oracle.py run \
  --repo "$REPO" --model "$DCMERGE_MODEL_DIR" --ft-dir "$DCMERGE_FT_DIR" \
  --heads "$DCMERGE_HEAD_DIR" --data "$DCMERGE_DATA_DIR" --exp2 "$EXP2" \
  --out "$OUT" --device cuda --contexts four 2>&1 | tee "$RESULTS/experiment3-four.log"

"$DCMERGE_MICROMAMBA" run -n "$DCMERGE_ENV_NAME" python lane_harm/run_oracle.py summarize --out "$OUT"
printf '[%s] Experiment 3 completed.\n' "$(date -u '+%F %T UTC')" | tee -a "$RESULTS/experiment3-runner.log"
