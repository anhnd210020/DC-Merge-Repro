# DC-Merge experiment and diagnostic archive

Created 2026-10-19 15:28 UTC.

This archive collects available experiment and diagnostic logs, compact results, setup records, and reports. It contains 258 inventoried source files (40,751,911 bytes before compression), including 41 `.log` files. Original absolute paths are retained as archive paths without the leading slash; for example, `/srv/dcmerge/results/experiment3-core.log` is stored as `srv/dcmerge/results/experiment3-core.log`.

Coverage includes Experiment 2 compare/decomposition and replay diagnostics; Experiment 3 baseline gates, audits, oracle summaries/results, final verification, and core/four runner logs; Experiment 4 task-transfer results, logs, and summaries; Hugging Face Xet logs; SUN397 download/extraction setup records; provisioning logs; earlier reproduction results; and the Experiment 1–3 methodology/report files available locally.

**Experiment 1 gap:** no standalone Experiment 1 run log or original complete Experiment 1 result set was found in the scanned project paths. The surviving Experiment 1 official guide and the later reproduction report/results are included, along with the references to Experiment 1 in the Experiment 2 notes.

The archive excludes dataset files, model weights, adapters/heads, downloaded archives, evaluation caches, general download caches, and credential stores. A credential-marker scan found no credential-like values in selected contents. No project source/result files were modified or deleted while making this archive.

`FILE_LIST.csv` identifies the included source paths, archive paths, categories, sizes, and SHA-256 values. `SHA256SUMS` verifies each member other than itself. The external `.sha256` sidecar verifies the compressed archive.
