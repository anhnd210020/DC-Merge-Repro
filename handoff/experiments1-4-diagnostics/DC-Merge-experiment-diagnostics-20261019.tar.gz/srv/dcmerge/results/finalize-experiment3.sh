#!/usr/bin/env bash
set -uo pipefail
LOG=/srv/dcmerge/results/experiment3-finalize.log
CHAIN=exp3-chain-20261018
FOUR=exp3-four-20261018
exec >>"$LOG" 2>&1
printf 'FINALIZER_START %s UTC\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
while ! tmux has-session -t "$FOUR" 2>/dev/null; do
  chain_dead=$(tmux display-message -p -t "$CHAIN" '#{pane_dead}' 2>/dev/null || printf 'missing')
  if [[ "$chain_dead" == 1 || "$chain_dead" == missing ]]; then
    printf 'BLOCKED chain ended before four session appeared\n'
    exit 91
  fi
  sleep 30
done
while :; do
  dead=$(tmux display-message -p -t "$FOUR" '#{pane_dead}' 2>/dev/null || printf 'missing')
  [[ "$dead" == 1 || "$dead" == missing ]] && break
  sleep 30
done
if [[ "$dead" == missing ]]; then printf 'BLOCKED four tmux session disappeared\n'; exit 92; fi
status=$(tmux display-message -p -t "$FOUR" '#{pane_dead_status}' 2>/dev/null || printf 'unknown')
printf 'FOUR_EXIT status=%s time=%s UTC\n' "$status" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
if [[ "$status" != 0 ]]; then printf 'BLOCKED four runner exited nonzero\n'; exit 93; fi
cd /workspace/ducanh/DC-Merge || exit 94
/workspace/bin/micromamba run -n dcmerge_vision python lane_harm/run_oracle.py summarize --out /srv/dcmerge/results/experiment3 || exit 95
cat >> /srv/dcmerge/results/experiment3/oracle_summary.md <<'NOTE'

## Baseline provenance warning

Primary `dc_rank` comparisons use the current-environment direct replay recorded in `/srv/dcmerge/results/experiment2-current-baseline/`; the archived Experiment 2 `compare/` files remain unchanged. Against the Oct 16 archived values, the largest selected-alpha per-task difference is +0.158353 pp on validation (GTSRB, `dtd-eurosat-gtsrb-svhn`) and -0.148148 pp on test (EuroSAT, `stanford_cars-eurosat-gtsrb-resisc45`). A repeated same-input current GPU evaluation was exact, while the historical 0.32 pp internal difference compared different arithmetic paths; this supports numerical sensitivity near decision boundaries but does not prove stochastic GPU variation or establish an archived run-to-run tolerance. See `baseline_replay_warning.md` and `/srv/dcmerge/results/experiment2-recreated/replay-diagnosis.md` for verified inputs and remaining historical uncertainties.
NOTE
python3 - <<'PY'
import csv, hashlib, json, math, pathlib, re, shutil, subprocess, sys
base=pathlib.Path('/srv/dcmerge/results')
out=base/'experiment3'
contexts=[
'dtd-eurosat-gtsrb-svhn','eurosat-gtsrb-mnist-svhn','eurosat-gtsrb-sun397-svhn',
'stanford_cars-eurosat-gtsrb-mnist','stanford_cars-eurosat-gtsrb-resisc45',
'stanford_cars-eurosat-mnist-resisc45','stanford_cars-eurosat-mnist-sun397']
core=contexts[:3]
report={'contexts':{},'warnings':[],'checks':{}}
means={m:[] for m in ('dc_rank','oracle_mean','oracle_fair')}
worsts={m:[] for m in ('dc_rank','oracle_mean','oracle_fair')}
core_means={m:[] for m in means}; core_worsts={m:[] for m in means}
max_val=max_test=max_lane=0.0
for cid in contexts:
    dpath=out/cid/'oracle_result.json'
    vp=out/cid/'val_cache.json'; tp=out/cid/'test_cache.json'
    if not all(p.is_file() for p in (dpath,vp,tp)):
        print('FAIL missing result/cache for',cid); sys.exit(1)
    d=json.loads(dpath.read_text()); vc=json.loads(vp.read_text()); tc=json.loads(tp.read_text())
    if d.get('context')!=cid or not all(x in d.get('test',{}) for x in ('dc_rank','oracle_mean','oracle_fair','ct')):
        print('FAIL incomplete context record',cid); sys.exit(1)
    if not all(x in d.get('val_chosen',{}) for x in ('mean','fair')):
        print('FAIL missing validation objective',cid); sys.exit(1)
    if not math.isfinite(float(d.get('val_evals',-1))) or not vc or len(tc)<1:
        print('FAIL empty cache or invalid val eval count',cid); sys.exit(1)
    checks=d['checks']; valdiff=float(checks['max_val_acc_diff_vs_exp2_pp']); testdiff=float(checks['max_test_acc_diff_vs_exp2_pp'])
    lane=float(checks['lane_checks']['max_rel_sum_error'])
    max_val=max(max_val,valdiff); max_test=max(max_test,testdiff); max_lane=max(max_lane,lane)
    if lane>=1e-4:
        print('FAIL lane arithmetic validation',cid,lane); sys.exit(1)
    vb=d['val_baseline']; vm=d['val_chosen']['mean']; vf=d['val_chosen']['fair']
    if vm['val_mean_norm']+1e-9 < vb['mean_norm'] or vf['val_mean_norm']+1e-9 < vb['mean_norm'] or vf['val_worst_norm']+1e-9 < vb['worst_norm']:
        print('FAIL validation objective/fair constraint',cid); sys.exit(1)
    for m in means:
        r=d['test'][m]
        if not math.isfinite(float(r['test_mean_norm'])) or not math.isfinite(float(r['test_worst_norm'])):
            print('FAIL nonfinite test metrics',cid,m); sys.exit(1)
        means[m].append(float(r['test_mean_norm'])); worsts[m].append(float(r['test_worst_norm']))
        if cid in core:
            core_means[m].append(float(r['test_mean_norm'])); core_worsts[m].append(float(r['test_worst_norm']))
    report['contexts'][cid]={
      'tasks':d['tasks'],'alpha':d['dc_rank_alpha'],'val_evals':d['val_evals'],
      'cache_counts':{'val':len(vc),'test':len(tc)},'baseline_diff_pp':{'val':valdiff,'test':testdiff},
      'lane_relative_sum_error':lane,'validation_baseline':vb,
      'val_mean':vm,'val_fair':vf,'test':d['test']}
    if valdiff>0.1 or testdiff>0.1: report['warnings'].append(f'{cid}: current-implementation reproduction difference exceeds 0.1 pp (logged, not used as a stop condition)')
# Verify summaries and complete row/context coverage.
md=out/'oracle_summary.md'; cp=out/'oracle.csv'
if not md.is_file() or not cp.is_file(): print('FAIL missing summary/CSV'); sys.exit(1)
summary=md.read_text(); rows=list(csv.DictReader(cp.open()))
if len(rows)!=28 or {r['context'] for r in rows}!=set(contexts):
    print('FAIL CSV coverage',len(rows),sorted({r['context'] for r in rows})); sys.exit(1)
if any(cid not in summary for cid in contexts) or 'Baseline provenance warning' not in summary:
    print('FAIL summary coverage/provenance'); sys.exit(1)
report['checks'].update({'result_records':7,'csv_rows':len(rows),'summary_contexts':7,
 'max_current_baseline_val_diff_pp':max_val,'max_current_baseline_test_diff_pp':max_test,
 'max_lane_relative_sum_error':max_lane})
# Confirm the archived Experiment 2 compare tree still matches its recorded aggregate hash.
e2=base/'experiment2'; fs=sorted((e2/'compare').glob('*.json')); all_files=sorted(p for p in (e2/'compare').iterdir() if p.is_file())
expected=re.search(r'([0-9a-f]{64})', (base/'experiment2-current-baseline/original-compare-file-list-hash.txt').read_text()).group(1)
raw=subprocess.run(['sha256sum',*[str(p) for p in fs]],check=True,capture_output=True).stdout
actual=hashlib.sha256(raw).hexdigest()
if len(all_files)!=25 or len(fs)!=23 or actual!=expected:
    print('FAIL archived Experiment 2 compare preservation',len(all_files),'files /',len(fs),'JSON',actual,expected); sys.exit(1)
report['checks']['experiment2_compare_files']=len(all_files); report['checks']['experiment2_compare_json_files']=len(fs); report['checks']['experiment2_compare_hash_unchanged']=True
# Average verdicts use paired mean/worst deltas for each oracle; combined rule follows the guide's best-of-two decision table.
def verdict(dm,dw):
    if dm>=1.0 and dw>=3.0: return 'HEADROOM: build the data-free predictor'
    if dw>0 and dm<0: return 'FAIRNESS ONLY: worst up, mean down'
    if dm<=0 and dw<=0: return 'NO HEADROOM: drop the method, write the analysis paper'
    return 'SMALL GAIN: below thresholds, discuss'
def aggregate(scope, mm, ww):
    n=len(mm['dc_rank']); values={}
    for m in ('oracle_mean','oracle_fair'):
        dm=sum(mm[m])/n-sum(mm['dc_rank'])/n; dw=sum(ww[m])/n-sum(ww['dc_rank'])/n
        values[m]={'delta_mean':dm,'delta_worst':dw,'verdict':verdict(dm,dw)}
    if any(v['verdict'].startswith('HEADROOM') for v in values.values()): combined='HEADROOM: build the data-free predictor'
    elif any(v['verdict'].startswith('FAIRNESS ONLY') for v in values.values()): combined='FAIRNESS ONLY: worst up, mean down'
    elif all(v['verdict'].startswith('NO HEADROOM') for v in values.values()): combined='NO HEADROOM: drop the method, write the analysis paper'
    else: combined='SMALL GAIN: below thresholds, discuss'
    return {'contexts':n,'per_oracle':values,'combined_best_of_two_verdict':combined}
report['verdicts']={'core':aggregate('core',core_means,core_worsts),'seven_contexts':aggregate('seven',means,worsts)}
# Ensure durable runner logs show success for both stages.
for name in ('experiment3-core.log','experiment3-four.log'):
    p=base/name
    if not p.is_file() or not re.search(r'END .* UTC exit=0',p.read_text(errors='replace')):
        print('FAIL missing successful runner end marker',name); sys.exit(1)
report['checks']['core_log_exit']=0; report['checks']['four_log_exit']=0
usage=shutil.disk_usage('/srv/dcmerge')
report['disk_bytes']={'total':usage.total,'used':usage.used,'free':usage.free}
(out/'final_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':report['checks'],'verdicts':report['verdicts'],'disk_bytes':report['disk_bytes']},indent=2))
print('FINAL_VERIFY_OK')
PY
