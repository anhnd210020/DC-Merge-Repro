#!/usr/bin/env bash
set -uo pipefail
LOG=/srv/dcmerge/results/experiment3-chain.log
CORE=exp3-core-20261018
FOUR=exp3-four-20261018
exec >>"$LOG" 2>&1
printf 'CHAIN_START %s UTC\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
while :; do
  dead=$(tmux display-message -p -t "$CORE" '#{pane_dead}' 2>/dev/null || printf 'missing')
  [[ "$dead" == 1 || "$dead" == missing ]] && break
  sleep 30
done
if [[ "$dead" == missing ]]; then
  printf 'BLOCKED core tmux session disappeared before completion\n'
  exit 91
fi
status=$(tmux display-message -p -t "$CORE" '#{pane_dead_status}' 2>/dev/null || printf 'unknown')
printf 'CORE_EXIT status=%s time=%s UTC\n' "$status" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
if [[ "$status" != 0 ]]; then
  printf 'BLOCKED core runner exited nonzero; four not started\n'
  exit 92
fi
python3 - <<'PY'
import json, pathlib, sys
root=pathlib.Path('/srv/dcmerge/results/experiment3')
contexts=('dtd-eurosat-gtsrb-svhn','eurosat-gtsrb-mnist-svhn','eurosat-gtsrb-sun397-svhn')
for name in contexts:
    p=root/name/'oracle_result.json'
    if not p.is_file():
        print(f'BLOCKED missing core result {p}'); sys.exit(1)
    d=json.loads(p.read_text())
    required=('val_chosen','test','checks','val_evals')
    if any(k not in d for k in required):
        print(f'BLOCKED incomplete core result {p}'); sys.exit(1)
    if not all(k in d['test'] for k in ('dc_rank','oracle_mean','oracle_fair')):
        print(f'BLOCKED missing core test evaluations {p}'); sys.exit(1)
    err=d['checks'].get('lane_checks',{}).get('max_rel_sum_error')
    if err is None or err >= 1e-4:
        print(f'BLOCKED invalid lane arithmetic check {p}: {err}'); sys.exit(1)
    print(f'CORE_RESULT_OK {name} lane_rel_error={err:.3g} val_evals={d["val_evals"]}')
PY
rc=$?
if [[ "$rc" != 0 ]]; then printf 'BLOCKED core result validation failed; four not started\n'; exit 93; fi
if tmux has-session -t "$FOUR" 2>/dev/null; then
  printf 'BLOCKED four tmux session already exists; refusing duplicate writer\n'
  exit 94
fi
tmux new-session -d -s "$FOUR" /srv/dcmerge/results/run-experiment3-four.sh || { printf 'BLOCKED could not create four tmux session\n'; exit 95; }
tmux set-option -t "$FOUR" remain-on-exit on
printf 'FOUR_STARTED session=%s time=%s UTC\n' "$FOUR" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
