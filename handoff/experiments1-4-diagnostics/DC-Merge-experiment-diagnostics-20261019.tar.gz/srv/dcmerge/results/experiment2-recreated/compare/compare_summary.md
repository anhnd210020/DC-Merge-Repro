# Experiment 2a: DC-Merge vs CT-Merging (test split, coefficient selected on validation)

| context | method | coef | mean acc | mean norm | worst norm (task) | EuroSAT acc |
|---|---|---:|---:|---:|---|---:|
| dtd-eurosat-gtsrb-svhn | dc_rank | 0.5 | 63.51 | 71.19 | 62.20 (eurosat) | 61.07 |
| dtd-eurosat-gtsrb-svhn | ct | 0.7 | 61.96 | 69.87 | 57.22 (svhn) | 67.15 |
| eurosat-gtsrb-mnist-svhn | dc_rank | 0.6 | 72.42 | 73.82 | 55.45 (eurosat) | 54.44 |
| eurosat-gtsrb-mnist-svhn | ct | 0.6 | 68.94 | 70.21 | 54.66 (svhn) | 67.30 |
| eurosat-gtsrb-sun397-svhn | dc_rank | 0.6 | 69.17 | 76.68 | 63.60 (eurosat) | 62.44 |
| eurosat-gtsrb-sun397-svhn | ct | 0.6 | 65.51 | 72.82 | 60.38 (svhn) | 66.52 |
| stanford_cars-eurosat-gtsrb-mnist | dc_rank | 0.6 | 75.62 | 81.59 | 72.16 (eurosat) | 70.85 |
| stanford_cars-eurosat-gtsrb-mnist | ct | 0.6 | 74.84 | 80.67 | 69.21 (gtsrb) | 77.56 |
| stanford_cars-eurosat-gtsrb-resisc45 | dc_rank | 0.7 | 78.71 | 85.50 | 80.58 (stanford_cars) | 87.00 |
| stanford_cars-eurosat-gtsrb-resisc45 | ct | 0.7 | 75.69 | 82.38 | 79.75 (gtsrb) | 84.44 |
| stanford_cars-eurosat-mnist-resisc45 | dc_rank | 0.6 | 80.73 | 87.68 | 85.93 (eurosat) | 84.37 |
| stanford_cars-eurosat-mnist-resisc45 | ct | 0.6 | 79.23 | 85.98 | 83.90 (stanford_cars) | 84.48 |
| stanford_cars-eurosat-mnist-sun397 | dc_rank | 0.7 | 77.75 | 89.61 | 84.76 (stanford_cars) | 86.33 |
| stanford_cars-eurosat-mnist-sun397 | ct | 0.7 | 78.45 | 90.23 | 83.88 (stanford_cars) | 90.11 |

## Averages over the 7 four-task contexts

| method | mean norm | mean worst norm | mean EuroSAT acc | contexts |
|---|---:|---:|---:|---:|
| dc_rank | 80.87 | 72.09 | 72.36 | 7 |
| ct | 78.88 | 69.86 | 76.79 | 7 |
