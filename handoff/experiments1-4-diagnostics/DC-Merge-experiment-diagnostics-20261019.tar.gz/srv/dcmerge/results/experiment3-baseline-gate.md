# Experiment 3 baseline gate

**Status: STOPPED before coordinate search.** The mandatory reproduction check failed.

## Exact lane-based check

- Baseline: `dtd-eurosat-gtsrb-svhn`, `dc_rank` α = 0.5, from the preserved `/srv/dcmerge/results/experiment2/compare/` files.
- Lane-based validation max absolute accuracy difference: **0.222 pp on EuroSAT**.
- The guide's stop threshold is 0.1 pp. The baseline-only gate exited before a test evaluation or coordinate search.
- No `oracle_result.json`, `oracle.csv`, or `oracle_summary.md` was produced. The reusable baseline validation cache was preserved at `experiment3/dtd-eurosat-gtsrb-svhn/val_cache.json`.

The durable gate output is `experiment3-baseline-gate.log`.

## Separate Experiment 2 replay comparison

The completed 14-file replay is in `experiment2-recreated/compare/`; it did not write to the original 25-file `experiment2/compare/` directory. Selected α matched in all seven contexts. Per-task differences at the original selected α were:

| Context | Max validation diff (task) | Max test diff (task) |
|---|---:|---:|
| dtd-eurosat-gtsrb-svhn | 0.158 pp (GTSRB) | 0.106 pp (DTD) |
| eurosat-gtsrb-mnist-svhn | 0.134 pp (SVHN) | 0.111 pp (EuroSAT) |
| eurosat-gtsrb-sun397-svhn | 0.050 pp (SUN397) | 0.111 pp (EuroSAT) |
| stanford_cars-eurosat-gtsrb-mnist | 0.074 pp (EuroSAT) | 0.059 pp (GTSRB) |
| stanford_cars-eurosat-gtsrb-resisc45 | 0.037 pp (EuroSAT) | 0.148 pp (EuroSAT) |
| stanford_cars-eurosat-mnist-resisc45 | 0.100 pp (MNIST) | 0.111 pp (EuroSAT) |
| stanford_cars-eurosat-mnist-sun397 | 0.050 pp (SUN397) | 0.074 pp (EuroSAT) |

Five replayed contexts exceeded 0.1 pp. This supports the direct lane-gate failure; it was not used as a substitute for that gate.

## Run state and preservation

- Experiment 3 `core` and `four` did not start.
- `/srv/dcmerge/results/experiment2/compare/` still has 25 files; no original results were modified.
- Setup reports `SETUP COMPLETE`; all required assets had passed provisioning validation.
- No files were deleted. Disk headroom at the stop was 24 GiB.
- The staged Sun397 archive had already been verified at 14,591,037,440 bytes with SHA-256 `38afed47c5acce92ac26b36b620e936f4a849e7934e30c65487a17e2dbe0c917` and extracted. The 12,406,746,644-byte Xet `.incomplete` file and its cache link remain preserved. The earlier Xet process had already been stopped before this continuation; no Xet downloader is active.

The orchestration script now points at the original Experiment 2 directory and runs all seven lane-based baseline checks before any search. `run_oracle.py` also checks validation and test reproduction before coordinate search.
