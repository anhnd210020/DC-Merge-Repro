#!/bin/bash
set -uo pipefail
source /workspace/dcmerge_env.sh || exit 90
cd /workspace/ducanh/DC-Merge
exec >> /srv/dcmerge/results/experiment3-core.log 2>&1
printf 'START %s UTC\n' "$(date -u +%%Y-%%m-%%dT%%H:%%M:%%SZ)"
/workspace/bin/micromamba run -n dcmerge_vision python lane_harm/run_oracle.py run \
  --repo /workspace/ducanh/DC-Merge \
  --model /workspace/models/clip-vit-base-patch32 \
  --ft-dir /workspace/models/DC-Merge-Vision-B32-r16-8task/lora_checkpoints \
  --heads /workspace/models/DC-Merge-Vision-B32-r16-8task/lora_heads \
  --data /workspace/datasets8 \
  --exp2 /srv/dcmerge/results/experiment2-current-baseline \
  --out /srv/dcmerge/results/experiment3 \
  --device cuda --contexts core
rc=$?
printf 'END %s UTC exit=%s\n' "$(date -u +%%Y-%%m-%%dT%%H:%%M:%%SZ)" "$rc"
exit "$rc"
