# Experiment 3 baseline diagnosis

Updated 2026-10-18 after the uniform-coefficient arithmetic fix.

## Finding and fix

`LaneMerge.compose()` originally multiplied each lane by the shared coefficient and then added the lane products. Experiment 2 applies the coefficient once to the completed DC-Merge update. These are algebraically equivalent but produce different float32 updates. In the first context this moved the EuroSAT validation score by 0.222 pp relative to the saved Experiment 2a result.

The uniform-vector path now scales the full update returned by the same traced merge. Per-task vectors still compose their individual lane terms. A tensor comparison for `dtd-eurosat-gtsrb-svhn`, alpha 0.5, reports `max_abs_vs_direct_scaled = 0.0`; the lane-sum relative error remains `1.69e-7`.

## Remaining mandatory gate failure

The strict gate was rerun from a fresh cache and stopped before test evaluation or coordinate search:

| Context | Split | Task | Difference | Limit |
|---|---|---|---:|---:|
| `dtd-eurosat-gtsrb-svhn` | validation | GTSRB | **0.158 pp** | 0.1 pp |

The direct DC-Merge replay also misses Experiment 2a: validation differs by 0.158 pp on GTSRB, and test differs by 0.106 pp on DTD. Two direct evaluations of each split in the current runtime returned identical per-task accuracies. Using the package archive or the current `/workspace/DC-Merge-Repro` checkout gives the same direct scores, so the remaining difference is not caused by choosing between those source trees.

## Provenance blocker

Experiment 2a results are dated 2026-10-16. The currently installed model bundle, heads, CLIP files, and `dcmerge_vision` environment were written or created on 2026-10-18; no older model copies or Torch installation remain under `/workspace`, `/srv`, `/root`, `/tmp`, or `/opt`. The current adapter files match the Hugging Face model revision `fcde80f8dccb513997c97e7215ff02a589b2994a`, committed 2026-09-20, but the saved Experiment 2a JSON does not record its asset hashes, runtime lock, or predictions. The old local inputs therefore cannot be identified or restored from this instance. This makes the residual source of the direct replay difference unresolvable from the saved outputs alone; attributing it specifically to weights or runtime would be an inference.

The remaining blocker is the missing provenance needed to reproduce the Experiment 2a input/runtime state. The 0.1 pp limit was not changed. The core/four oracle did not start.

## Preserved state

- Original `/srv/dcmerge/results/experiment2/compare/` remains intact with 25 files.
- The pre-fix validation cache is preserved as `experiment3/dtd-eurosat-gtsrb-svhn/val_cache.pre_uniform_compose_fix.json`; the new `val_cache.json` contains the post-fix direct baseline evaluation.
- No `oracle_result.json`, `oracle.csv`, or `oracle_summary.md` was written. No test cache or other context cache was created.
- The 14-file `experiment2-recreated/compare/` replay, prior gate logs, model/data caches, verified Sun397 archive, and Xet `.incomplete` file remain intact. No files were deleted.

Logs: `experiment3-baseline-gate-after-uniform-fix.log`, `experiment3-uniform-compose-fix-check.log`, and `experiment3-baseline-diagnostic.log`.
