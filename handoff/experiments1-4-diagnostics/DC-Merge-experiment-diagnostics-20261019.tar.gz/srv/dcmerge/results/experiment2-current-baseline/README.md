# Current-environment Experiment 2 baseline overlay

Keep archived Experiment 2a selected alpha; use current direct replay val accuracy at that alpha and current direct replay test accuracy as primary dc_rank baseline. CT rows and coefficients remain the archived Experiment 2a values.

The original `/srv/dcmerge/results/experiment2/compare/` files were not modified. This overlay copies the archived `dc_rank`/`ct` JSON inputs and updates only the selected-alpha `dc_rank` validation accuracies and `test_acc` from the current direct replay. The archived selected coefficient must match the current replay selection for each context; all seven matched. The oracle still uses the unchanged grid, objectives, two-pass maximum, and 0.1 pp internal reproduction gate, which now compares against the current-environment baseline. Archived-versus-current differences are recorded separately in `manifest.json`.

Maximum val discrepancy: +0.158353 pp for `dtd-eurosat-gtsrb-svhn` / `gtsrb` at alpha 0.5 (archived 73.950911%, current 74.109264%).
Maximum test discrepancy: -0.148148 pp for `stanford_cars-eurosat-gtsrb-resisc45` / `eurosat` at alpha 0.7 (archived 87.148148%, current 87.000000%).
