import os

VIT_ARCH = 'ViT-B-16'    # Model Architecture (Uncomment for ViT-B-16-CLIP)
# VIT_ARCH = 'ViT-L-14'    # Model Architecture (Uncomment for ViT-L-14-CLIP)
# VIT_ARCH = 'ViT-B-32'      # Model Architecture (Uncomment for ViT-B-32-CLIP)
MODEL_DIR = ''                  # Model Directory
CACHE_DIR = ''                  # Where to cache HF pretrained checkpoints
HEAD_DIR = ''                   # CLIP Head Directory

if VIT_ARCH == 'ViT-L-14':
    BASE_TYPE = "ViT-L-14"
elif VIT_ARCH == 'ViT-B-16':
    BASE_TYPE = "ViT-B-16"
elif VIT_ARCH == 'ViT-B-32':
    BASE_TYPE = "ViT-B-32"

config = {
    'dataset': [
        {
            'name': 'stanford_cars',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'stanford_cars_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 16,
            'shuffled_idxs': os.path.join(os.getcwd(), 'dataset/shuffled_idxs/cars_shuffled_idxs.pt')
        },
        {
            'name': 'dtd',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'dtd_head.pt'),
            'batch_size': 32,
            'num_workers': 16,
        },
        {
            'name': 'eurosat',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'eurosat_head.pt'),
            'batch_size': 32,
            'num_workers': 16,
        },
        {
            'name': 'gtsrb',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'gtsrb_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 16,
            'shuffled_idxs': os.path.join(os.getcwd(), 'dataset/shuffled_idxs/gtsrb_shuffled_idxs.pt')
        },
        {
            'name': 'mnist',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'mnist_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,  
            'shuffled_idxs': os.path.join(os.getcwd(), 'dataset/shuffled_idxs/mnist_shuffled_idxs.pt')
        },
        {
            'name': 'resisc45',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'resisc45_head.pt'),
            'batch_size': 32,
            'num_workers': 16,
        },
        {
            'name': 'sun397',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'sun397_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 16,
            'shuffled_idxs': os.path.join(os.getcwd(), 'dataset/shuffled_idxs/sun397_shuffled_idxs.pt')
        },
        {
            'name': 'svhn',
            'shuffle_train': True,
            'crop_ratio': 1.0,
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'svhn_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,
            'shuffled_idxs': os.path.join(os.getcwd(), 'dataset/shuffled_idxs/svhn_shuffled_idxs.pt')
        },
        {
            'name': 'cifar100',
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'cifar100_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,
        },
        {
            'name': 'flowers102',
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'flowers102_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,
        },
        {
            'name': 'oxfordpets',
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'oxfordpets_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,
        },
        {
            'name': 'stl10',
            'clip_encodings': os.path.join(HEAD_DIR, VIT_ARCH, 'stl10_head.pt'),
            'val_fraction': 0.2,
            'batch_size': 32,
            'num_workers': 8,
        },
    ],
    'model': {
        'name': 'hf_clip',
        'base_type': BASE_TYPE,
        'cachedir': CACHE_DIR,
        'bases': [],
        'ft_config': {
            'type': 'lora',
            'r': 16,
            'lora_alpha': 16,
            'target_modules': ["q_proj", "k_proj", "v_proj", "out_proj"],
            'lora_dropout': 0.1,
            'bias': "none",
        },
    },
    'eval_type': 'clip',
}
